import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java. util. Random;


public class MapGeneratorAndMonsterGenerator {

 private static String[][] map = new String[11][11];
 private static String config = new String();
 private static int level;
 private static int difficulty;
 
 private static long seed;
 private static int intseed;
 private static String StringSeed;
 
 public static String[][] readMap(String fileName){
  try{
   BufferedReader in = new BufferedReader(new FileReader(fileName));
   String str;
   int i = 0;
   
   while ((str = in.readLine()) != null){
          for (int j = 0;j<44;j+=4){
              map[i][(int)j/4] = str.substring(j, j+4);
          }
          i++;
   }
  }
  catch (IOException e) {
      System.out.println("sb");
  }
  return map;
 }
 
 public static String[][] randomPool(String[][] [] pool){
       Random r = new Random();        
       int randomNumber=r.nextInt(pool.length);
       return pool[randomNumber];
 }
 
 public static int GetSeed(String fileName){
  
  String LeftSeed =  String.valueOf((int)config.charAt(0)) + String.valueOf((int)config.charAt(1)) + String.valueOf((int)config.charAt(2)) + String.valueOf((int)config.charAt(3));
  String RightSeed = String.valueOf((int)config.charAt(4)) + String.valueOf((int)config.charAt(5)) + String.valueOf((int)config.charAt(6)) + String.valueOf((int)config.charAt(7));
    
  StringSeed = LeftSeed+RightSeed;
  seed = Long.parseLong(LeftSeed) + Long.parseLong(RightSeed);
  intseed = Math.abs((int)seed);
  return intseed;
 }

 public static void readConfig(String fileName){
  try{
       BufferedReader in = new BufferedReader(new FileReader(fileName));
       String str;
       int i = 0;
       
       str = in.readLine();
       config = str;
       str = in.readLine();
       level = Integer.parseInt(str);
       str = in.readLine();
       difficulty = Integer.parseInt(str);
       in.close();
     }
     catch (IOException e) {
       System.out.println("sb");
     }
 }
 
 public static int getMaxLevel(String fileName){
  return level;
 }
 
 public static String[][] createMap (int seed, int currLevel) {
  //Boss Room
  String[][] bossRoom = new String[11][11];
  bossRoom[9][5] = "S000";
  for (int i = 0; i < bossRoom.length; i++) {
   for (int j = 0; j < bossRoom.length; j++) {
    bossRoom[i][0] = "W000";
    bossRoom[0][j] = "W000";
    bossRoom[i][10] = "W000";
    bossRoom[10][j] = "W000";
    bossRoom[i][1] = "~~~~";
    bossRoom[1][j] = "~~~~";
   }
  }
  bossRoom[1][10] = "W000";
  bossRoom[1][0] = "W000";
  bossRoom[10][1] = "W000";
  bossRoom[8][5] = "C000";
  
  //Normal Room
  
  //0
  String[][] normalRoom0 = new String[11][11];
  //Boundaries
  for (int i = 1; i < normalRoom0.length; i++) {
   for (int j = 0; j < normalRoom0.length; j++) {
    normalRoom0[i][0] = "W000";
    normalRoom0[0][j] = "W000";
    normalRoom0[i][10] = "W000";
    normalRoom0[10][j] = "W000";
    normalRoom0[i][1] = "~~~~";
    normalRoom0[1][j] = "~~~~";
   }
  }
  normalRoom0[1][10] = "W000";
  normalRoom0[1][0] = "W000";
  normalRoom0[10][1] = "W000";
  normalRoom0[1][1] = "S001";
  normalRoom0[9][9] = "S000";
  normalRoom0[8][9] = "C000";
  normalRoom0[7][7] = "D000";
  normalRoom0[5][5] = "K000";
  
  //horizontal
  for (int i = 1; i <= 7; i++) {
   normalRoom0[i][3] = "W000";
  }
  
  for (int i = 2; i <= 9; i++) {
   normalRoom0[i][8] = "W000";
  }
  
  //vertical
  
  for (int i = 3; i <= 6; i++) {
   normalRoom0[7][i] = "W000";
  }
  
  for (int i = 5; i <= 8; i++) {
   normalRoom0[2][i] = "W000";
  }
  
  //1
  String[][] normalRoom1 = new String[11][11];
  for (int i = 1; i < normalRoom1.length; i++) {
   for (int j = 0; j < normalRoom1.length; j++) {
    normalRoom1[i][0] = "W000";
    normalRoom1[0][j] = "W000";
    normalRoom1[i][10] = "W000";
    normalRoom1[10][j] = "W000";
    normalRoom1[i][1] = "~~~~";
    normalRoom1[1][j] = "~~~~";
   }
  }
  normalRoom1[1][10] = "W000";
  normalRoom1[1][0] = "W000";
  normalRoom1[10][1] = "W000";
  normalRoom1[1][1] = "S001";
  normalRoom1[9][9] = "S000";
  normalRoom1[9][8] = "C000";
  normalRoom1[5][9] = "K000";
  normalRoom1[5][1] = "K000";
  normalRoom1[5][4] = "D000";
  
  for (int i = 0; i <5; i++) {
   normalRoom1[2][i] = "W000";
   normalRoom1[4][i] = "W000";
   normalRoom1[6][i] = "W000";
  }
  
  for (int i = 6;  i < 10; i++) {
   normalRoom1[3][i] = "W000";
   normalRoom1[7][i] = "W000";
  }
  
  
  
  //2
  String[][] normalRoom2 = new String[11][11];
  for (int i = 1; i < normalRoom2.length; i++) {
   for (int j = 0; j < normalRoom2.length; j++) {
    normalRoom2[i][0] = "W000";
    normalRoom2[0][j] = "W000";
    normalRoom2[i][10] = "W000";
    normalRoom2[10][j] = "W000";
    normalRoom2[i][1] = "~~~~";
    normalRoom2[1][j] = "~~~~";
   }
  }
  normalRoom2[1][10] = "W000";
  normalRoom2[1][0] = "W000";
  normalRoom2[10][1] = "W000";
  normalRoom2[8][9] = "C000";
  normalRoom2[9][9] = "S000";
  normalRoom2[1][1] = "S001";
  normalRoom2[8][3] = "K000";
  normalRoom2[7][2] = "K000";
  normalRoom2[3][1] = "D000";
  normalRoom2[3][9] = "D000";
  
  //horizontal
  for (int i = 0; i < 4; i++) {
   normalRoom2[i][4] = "W000";
   normalRoom2[i][6] = "W000";
  }
  
  for (int i = 6; i < 10; i++) {
   normalRoom2[i][4] = "W000";
   normalRoom2[i][6] = "W000";
  }
  
  //vertical
  for (int i = 2; i < 5; i++) {
   normalRoom2[3][i] = "W000";
   normalRoom2[7][i] = "W000";
  }
  
  for (int i = 6; i < 9; i++) {
   normalRoom2[3][i] = "W000";
   normalRoom2[7][i] = "W000";
  }
  
  
  //3
  String[][] normalRoom3 = new String[11][11];
  //Boundaries
  for (int i = 1; i < normalRoom3.length; i++) {
   for (int j = 0; j < normalRoom3.length; j++) {
    normalRoom3[i][0] = "W000";
    normalRoom3[0][j] = "W000";
    normalRoom3[i][10] = "W000";
    normalRoom3[10][j] = "W000";
    normalRoom3[i][1] = "~~~~";
    normalRoom3[1][j] = "~~~~";
   }
  }
  normalRoom3[1][10] = "W000";
  normalRoom3[1][0] = "W000";
  normalRoom3[10][1] = "W000";
  normalRoom3[8][9] = "C000";
  normalRoom3[9][9] = "S000";
  normalRoom3[1][4] = "S001";
  normalRoom3[1][1] = "K000";
  normalRoom3[9][1] = "K000";
  normalRoom3[4][4] = "D000";
  normalRoom3[6][4] = "D000";
  
  //horizontal
  for (int i = 0; i < 5; i++) {
   normalRoom3[i][2] = "W000";
   normalRoom3[i][6] = "W000";
  }
  
  for (int i = 6; i < 10; i++) {
   normalRoom3[i][2] = "W000";
   normalRoom3[i][6] = "W000";
  }
  
  for (int i = 2; i <= 4; i++) {
   normalRoom3[i][8] = "W000";
  }
  
  for (int i = 6; i <= 8; i++){
   normalRoom3[i][8] = "W000";
  }
  
  //vertical
  for (int i = 2; i <= 3; i++) {
   normalRoom3[4][i] = "W000";
   normalRoom3[6][i] = "W000";
  }
  
  for (int i = 5; i <= 7; i++) {
   normalRoom3[4][i] = "W000";
   normalRoom3[6][i] = "W000";
  }
  
  for (int i = 8; i <= 8; i++) {
   normalRoom3[2][i] = "W000";
   normalRoom3[8][i] = "W000";
  }
  

  
  //4
  String[][] normalRoom4 = new String[11][11];
  //Boundaries
  for (int i = 1; i < normalRoom4.length; i++) {
   for (int j = 0; j < normalRoom4.length; j++) {
    normalRoom4[i][0] = "W000";
    normalRoom4[0][j] = "W000";
    normalRoom4[i][10] = "W000";
    normalRoom4[10][j] = "W000";
    normalRoom4[i][1] = "~~~~";
    normalRoom4[1][j] = "~~~~";
   }
  }
  normalRoom4[1][10] = "W000";
  normalRoom4[1][0] = "W000";
  normalRoom4[10][1] = "W000";
  normalRoom4[9][8] = "C000";
  normalRoom4[9][9] = "S000";
  normalRoom4[5][1] = "S001";
  normalRoom4[1][1] = "K000";
  normalRoom4[9][1] = "K000";
  normalRoom4[5][3] = "D000";
  normalRoom4[1][3] = "D000";
  
  //horizontal
  for (int i = 2; i <= 4; i++) {
   normalRoom4[i][3] = "W000";
  }
  
  for (int i = 6; i <= 8; i++) {
   normalRoom4[i][3] = "W000";
  }
  
  for (int i = 4; i <= 9; i++) {
   normalRoom4[i][5] = "W000";
  }
  
  for (int i = 4; i <= 6; i++){
   normalRoom4[i][7] = "W000";
  }
  
  //vertical
  for (int i = 1; i <= 3; i++) {
   normalRoom4[3][i] = "W000";
   normalRoom4[7][i] = "W000";
  }
  
  for (int i = 7; i <= 9; i++) {
   normalRoom4[2][i] = "W000";
   normalRoom4[5][i] = "W000";
   normalRoom4[8][i] = "W000";
  }
  
  //5
  String[][] normalRoom5 = new String[11][11];
  //Boundaries
  for (int i = 1; i < normalRoom4.length; i++) {
   for (int j = 0; j < normalRoom4.length; j++) {
    normalRoom5[i][0] = "W000";
    normalRoom5[0][j] = "W000";
    normalRoom5[i][10] = "W000";
    normalRoom5[10][j] = "W000";
    normalRoom5[i][1] = "~~~~";
    normalRoom5[1][j] = "~~~~";
   }
  }
  normalRoom5[1][10] = "W000";
  normalRoom5[1][0] = "W000";
  normalRoom5[10][1] = "W000";
  normalRoom5[1][9] = "S000";
  normalRoom5[9][1] = "S001";
  normalRoom5[9][9] = "K000";
  normalRoom5[9][4] = "K000";
  normalRoom5[1][6] = "D000";
  normalRoom5[1][2] = "D000";
  
  //vertical
  for (int i = 2; i <= 9; i++) {
   normalRoom5[i][2] = "W000";
   normalRoom5[i][6] = "W000";
  }
  
  for (int i = 1; i <= 8; i++) {
   normalRoom5[i][4] = "W000";
   normalRoom5[i][8] = "W000";
  }
  
  
  //6
  String[][] normalRoom6 = new String[11][11];
  //Boundaries
  for (int i = 1; i < normalRoom6.length; i++) {
   for (int j = 0; j < normalRoom6.length; j++) {
    normalRoom6[i][0] = "W000";
    normalRoom6[0][j] = "W000";
    normalRoom6[i][10] = "W000";
    normalRoom6[10][j] = "W000";
    normalRoom6[i][1] = "~~~~";
    normalRoom6[1][j] = "~~~~";
   }
  }
  normalRoom6[1][10] = "W000";
  normalRoom6[1][0] = "W000";
  normalRoom6[10][1] = "W000";
  normalRoom6[8][9] = "C000";
  normalRoom6[9][9] = "S000";
  normalRoom6[5][5] = "S001";
  normalRoom6[5][2] = "D000";
  normalRoom6[5][8] = "D000";
  normalRoom6[2][5] = "D000";
  normalRoom6[8][5] = "D000";
  normalRoom6[1][9] = "K000";
  normalRoom6[1][1] = "K000";
  normalRoom6[9][1] = "K000";
  
  //horizontal
  for (int i = 2; i <= 4; i++) {
   normalRoom6[i][2] = "W000";
   normalRoom6[i][8] = "W000";
  }
  
  for (int i = 6; i <= 8; i++) {
   normalRoom6[i][2] = "W000";
   normalRoom6[i][8] = "W000";
  }
  
  //vertical
  for (int i = 2; i <= 4; i++) {
   normalRoom6[2][i] = "W000";
   normalRoom6[8][i] = "W000";
  }
  for (int i = 6; i <= 8; i++) {
   normalRoom6[2][i] = "W000";
   normalRoom6[8][i] = "W000";
  }
  
  //7
  String[][] normalRoom7 = new String[11][11];
  //Boundaries
  for (int i = 1; i < normalRoom7.length; i++) {
   for (int j = 0; j < normalRoom7.length; j++) {
    normalRoom7[i][0] = "W000";
    normalRoom7[0][j] = "W000";
    normalRoom7[i][10] = "W000";
    normalRoom7[10][j] = "W000";
    normalRoom7[i][1] = "~~~~";
    normalRoom7[1][j] = "~~~~";
   }
  }
  normalRoom7[1][10] = "W000";
  normalRoom7[1][0] = "W000";
  normalRoom7[10][1] = "W000";
  normalRoom7[9][1] = "S001";
  normalRoom7[5][9] = "S000";
  normalRoom7[5][8] = "C000";
  normalRoom7[6][1] = "D000";
  normalRoom7[1][9] = "K000";
  
  //horizontal
  for (int i = 3; i <= 9; i++) {
   normalRoom7[i][3] = "W000";
   normalRoom7[i][7] = "W000";
  }
  
  for (int i = 6; i <= 8; i++) {
   normalRoom7[i][2] = "W000";
   normalRoom7[i][8] = "W000";
  }
  
  //vertical
  for (int i = 2; i <= 4; i++) {
   normalRoom7[3][i] = "W000";
  }
  
  for (int i = 3; i <= 4; i++) {
   normalRoom7[5][i] = "W000";
   normalRoom7[7][i] = "W000";
   normalRoom7[9][i] = "W000";
  }
  
  
  for (int i = 6; i <= 7; i++) {
   normalRoom7[3][i] = "W000";
   normalRoom7[5][i] = "W000";
   normalRoom7[7][i] = "W000";
   normalRoom7[9][i] = "W000";
  }
  
  
  
  //8
  String[][] normalRoom8 = new String[11][11];
  //Boundaries
  for (int i = 1; i < normalRoom8.length; i++) {
   for (int j = 0; j < normalRoom8.length; j++) {
    normalRoom8[i][0] = "W000";
    normalRoom8[0][j] = "W000";
    normalRoom8[i][10] = "W000";
    normalRoom8[10][j] = "W000";
    normalRoom8[i][1] = "~~~~";
    normalRoom8[1][j] = "~~~~";
   }
  }
  normalRoom8[1][10] = "W000";
  normalRoom8[1][0] = "W000";
  normalRoom8[10][1] = "W000";
  normalRoom8[9][5] = "S001";
  normalRoom8[1][5] = "S000";
  normalRoom8[2][5] = "C000";
  normalRoom8[4][1] = "D000";
  normalRoom8[6][1] = "D000";
  normalRoom8[1][9] = "K000";
  normalRoom8[9][9] = "K000";
  
  //horizontal
  for (int i = 1; i <= 4; i++) {
   normalRoom8[i][4] = "W000";
   normalRoom8[i][6] = "W000";
  }
  
  for (int i = 6; i <= 9; i++) {
   normalRoom8[i][4] = "W000";
   normalRoom8[i][6] = "W000";
  }
  
  for (int i = 2; i <= 3; i++) {
   normalRoom8[i][2] = "W000";
   normalRoom8[i][8] = "W000";
  }
  
  for (int i = 7; i <= 8; i++) {
   normalRoom8[i][2] = "W000";
   normalRoom8[i][8] = "W000";
  }
  
  //vertical
  for (int i = 2; i <= 4; i++) {
   normalRoom8[4][i] = "W000";
   normalRoom8[6][i] = "W000";
  }
  
  for (int i = 6; i <= 8; i++) {
   normalRoom8[4][i] = "W000";
   normalRoom8[6][i] = "W000";
  }
  
  //9
  String[][] normalRoom9 = new String[11][11];
  //Boundaries
  for (int i = 1; i < normalRoom9.length; i++) {
   for (int j = 0; j < normalRoom9.length; j++) {
    normalRoom9[i][0] = "W000";
    normalRoom9[0][j] = "W000";
    normalRoom9[i][10] = "W000";
    normalRoom9[10][j] = "W000";
    normalRoom9[i][1] = "~~~~";
    normalRoom9[1][j] = "~~~~";
   }
  }
  normalRoom9[1][10] = "W000";
  normalRoom9[1][0] = "W000";
  normalRoom9[10][1] = "W000";
  normalRoom9[1][1] = "S001";
  normalRoom9[9][9] = "S000";
  normalRoom9[8][9] = "C000";
  
  normalRoom9[5][8] = "D000";
  normalRoom9[6][1] = "D000";
  normalRoom9[4][1] = "D000";
  normalRoom9[1][9] = "K000";
  normalRoom9[9][1] = "K000";
  
  //horizontal
  for (int i = 1; i <= 4; i++) {
   normalRoom9[i][6] = "W000";
   normalRoom9[i][5] = "W000";
   normalRoom9[i][4] = "W000";
  }
  
  for (int i = 6; i <= 9; i++) {
   normalRoom9[i][6] = "W000";
   normalRoom9[i][5] = "W000";
   normalRoom9[i][4] = "W000";
  }
  
  //vertical
  
  for (int i = 6; i <= 8; i++) {
   normalRoom9[4][i] = "W000";
   normalRoom9[6][i] = "W000";
  }
  
  for (int i = 2; i <= 3; i++) {
   normalRoom9[4][i] = "W000";
   normalRoom9[6][i] = "W000";
  }
  
  //10
  String[][] normalRoom10 = new String[11][11];
  //Boundaries
  for (int i = 1; i < normalRoom10.length; i++) {
   for (int j = 0; j < normalRoom10.length; j++) {
    normalRoom10[i][0] = "W000";
    normalRoom10[0][j] = "W000";
    normalRoom10[i][10] = "W000";
    normalRoom10[10][j] = "W000";
    normalRoom10[i][1] = "~~~~";
    normalRoom10[1][j] = "~~~~";
   }
  }
  normalRoom10[1][10] = "W000";
  normalRoom10[1][0] = "W000";
  normalRoom10[10][1] = "W000";
  normalRoom10[1][1] = "S001";
  normalRoom10[9][9] = "S000";
  normalRoom10[8][9] = "C000";
  normalRoom10[3][4] = "D000";
  normalRoom10[1][5] = "K000";
  normalRoom10[9][5] = "K000";
  
  //horizontal

  
  //vertical
  
  for (int i = 1; i <= 3; i++) {
   normalRoom10[3][i] = "W000";
   normalRoom10[7][i] = "W000";
  }
  
  for (int i = 5; i <= 9; i++) {
   normalRoom10[3][i] = "W000";
   normalRoom10[7][i] = "W000";
  }
  
  for (int i = 3; i <= 6; i++) {
   normalRoom10[5][i] = "W000";
  }
  
  //11
  String[][] normalRoom11 = new String[11][11];
  //Boundaries
  for (int i = 1; i < normalRoom11.length; i++) {
   for (int j = 0; j < normalRoom11.length; j++) {
    normalRoom11[i][0] = "W000";
    normalRoom11[0][j] = "W000";
    normalRoom11[i][10] = "W000";
    normalRoom11[10][j] = "W000";
    normalRoom11[i][1] = "~~~~";
    normalRoom11[1][j] = "~~~~";
   }
  }
  normalRoom11[1][10] = "W000";
  normalRoom11[1][0] = "W000";
  normalRoom11[10][1] = "W000";
  normalRoom11[2][1] = "C000";
  normalRoom11[1][1] = "S000";
  normalRoom11[5][5] = "S001";
  normalRoom11[6][5] = "D000";
  normalRoom11[9][9] = "K000";
  
  //horizontal
  for (int i = 2; i <= 8; i++) {
   normalRoom11[i][2] = "W000";
   normalRoom11[i][8] = "W000";
  }
  
  for (int i = 4; i <= 6; i++) {
   normalRoom11[i][6] = "W000";
   normalRoom11[i][4] = "W000";
  }
  
  //vertical
  
  for (int i = 2; i <= 4; i++) {
   normalRoom11[2][i] = "W000";
  }
  
  for (int i = 6; i <= 8; i++) {
   normalRoom11[2][i] = "W000";
  }
  
  for (int i = 4; i <= 6; i++) {
   normalRoom11[4][i] = "W000";
  }
  
  for (int i = 2; i <= 8; i++) {
   normalRoom11[8][i] = "W000";
  }
  
  //12
    String[][] normalRoom12 = new String[11][11];
    //Boundaries
    for (int i = 1; i < normalRoom4.length; i++) {
     for (int j = 0; j < normalRoom4.length; j++) {
      normalRoom12[i][0] = "W000";
      normalRoom12[0][j] = "W000";
      normalRoom12[i][10] = "W000";
      normalRoom12[10][j] = "W000";
      normalRoom12[i][1] = "~~~~";
      normalRoom12[1][j] = "~~~~";
     }
    }
    normalRoom12[1][10] = "W000";
    normalRoom12[1][0] = "W000";
    normalRoom12[10][1] = "W000";
    normalRoom12[8][5] = "C000";
    normalRoom12[9][5] = "S000";
    normalRoom12[1][5] = "S001";
    normalRoom12[1][2] = "K000";
    normalRoom12[1][8] = "K000";
    normalRoom12[5][5] = "D000";
    normalRoom12[3][5] = "D000";
    
    //vertical
    for (int i = 1; i <= 8; i++) {
     normalRoom12[i][4] = "W000";
    }
    
    for (int i = 1; i <= 3; i++) {
     normalRoom12[i][6] = "W000";
    }
    
    for (int i = 5; i <= 9; i++) {
     normalRoom12[i][6] = "W000";
    }
    
    //horizontal
    for (int i = 1; i <= 1; i++) {
     normalRoom12[5][i] = "W000";
    }
    
    for (int i = 3; i <= 3; i++) {
     normalRoom12[5][i] = "W000";
    }
    
    //13
    String[][] normalRoom13 = new String[11][11];
    //Boundaries
    for (int i = 1; i < normalRoom4.length; i++) {
     for (int j = 0; j < normalRoom4.length; j++) {
      normalRoom13[i][0] = "W000";
      normalRoom13[0][j] = "W000";
      normalRoom13[i][10] = "W000";
      normalRoom13[10][j] = "W000";
      normalRoom13[i][1] = "~~~~";
      normalRoom13[1][j] = "~~~~";
     }
    }
    normalRoom13[1][10] = "W000";
    normalRoom13[1][0] = "W000";
    normalRoom13[10][1] = "W000";
    normalRoom13[8][9] = "C000";
    normalRoom13[9][9] = "S000";
    normalRoom13[1][5] = "S001";
    normalRoom13[9][1] = "K000";
    normalRoom13[4][9] = "K000";
    normalRoom13[7][5] = "D000";
    normalRoom13[3][5] = "D000";
    
    //vertical
    
    //horizontal
    for (int i = 1; i <= 4; i++) {
     normalRoom13[3][i] = "W000";
     normalRoom13[7][i] = "W000";
    }
    
    for (int i = 6; i <= 9; i++) {
     normalRoom13[3][i] = "W000";
     normalRoom13[7][i] = "W000";
    }
    
    //14
    String[][] normalRoom14 = new String[11][11];
    //Boundaries
    for (int i = 1; i < normalRoom4.length; i++) {
     for (int j = 0; j < normalRoom4.length; j++) {
      normalRoom14[i][0] = "W000";
      normalRoom14[0][j] = "W000";
      normalRoom14[i][10] = "W000";
      normalRoom14[10][j] = "W000";
      normalRoom14[i][1] = "~~~~";
      normalRoom14[1][j] = "~~~~";
     }
    }
    normalRoom14[1][10] = "W000";
    normalRoom14[1][0] = "W000";
    normalRoom14[10][1] = "W000";
    normalRoom14[8][5] = "C000";
    normalRoom14[9][5] = "S000";
    normalRoom14[1][5] = "S001";
    normalRoom14[8][2] = "K000";
    normalRoom14[8][8] = "K000";
    normalRoom14[8][6] = "D000";
    normalRoom14[3][5] = "D000";
    
    //vertical
    for (int i = 1; i <= 3; i++) {
     normalRoom14[i][3] = "W000";
    }
    
    for (int i = 1; i <= 3; i++) {
     normalRoom14[i][7] = "W000";
    }
    
    for (int i = 6; i <= 7; i++) {
     normalRoom14[i][4] = "W000";
    }
    
    for (int i = 6; i <= 7; i++) {
     normalRoom14[i][6] = "W000";
    }
    
    for (int i = 9; i <= 9; i++) {
     normalRoom14[i][4] = "W000";
    }
    
    for (int i = 9; i <= 9; i++) {
     normalRoom14[i][6] = "W000";
    }
    
    //horizontal
    for (int i = 3; i <= 4; i++) {
     normalRoom14[3][i] = "W000";
    }
    
    for (int i = 6; i <= 7; i++) {
     normalRoom14[3][i] = "W000";
    }
    
    for (int i = 1; i <= 4; i++) {
     normalRoom14[6][i] = "W000";
    }
    
    for (int i = 6; i <= 9; i++) {
     normalRoom14[6][i] = "W000";
    }
    
    //15
    String[][] normalRoom15 = new String[11][11];
    //Boundaries
    for (int i = 1; i < normalRoom4.length; i++) {
     for (int j = 0; j < normalRoom4.length; j++) {
      normalRoom15[i][0] = "W000";
      normalRoom15[0][j] = "W000";
      normalRoom15[i][10] = "W000";
      normalRoom15[10][j] = "W000";
      normalRoom15[i][1] = "~~~~";
      normalRoom15[1][j] = "~~~~";
     }
    }
    normalRoom15[1][10] = "W000";
    normalRoom15[1][0] = "W000";
    normalRoom15[10][1] = "W000";
    normalRoom15[6][4] = "W000";
    normalRoom15[7][3] = "W000";
    normalRoom15[9][1] = "W000";
    normalRoom15[6][6] = "W000";
    normalRoom15[7][7] = "W000";
    normalRoom15[9][9] = "W000";
    normalRoom15[2][1] = "C000";
    normalRoom15[1][1] = "S000";
    normalRoom15[1][9] = "S001";
    normalRoom15[4][4] = "K000";
    normalRoom15[8][5] = "K000";
    normalRoom15[8][2] = "D000";
    normalRoom15[8][8] = "D000";
    
    //vertical
    for (int i = 1; i <= 5; i++) {
     normalRoom15[i][5] = "W000";
    }
    //horizontal

    
    //16
    String[][] normalRoom16 = new String[11][11];
    //Boundaries
    for (int i = 1; i < normalRoom4.length; i++) {
     for (int j = 0; j < normalRoom4.length; j++) {
      normalRoom16[i][0] = "W000";
      normalRoom16[0][j] = "W000";
      normalRoom16[i][10] = "W000";
      normalRoom16[10][j] = "W000";
      normalRoom16[i][1] = "~~~~";
      normalRoom16[1][j] = "~~~~";
     }
    }
    normalRoom16[1][10] = "W000";
    normalRoom16[1][0] = "W000";
    normalRoom16[10][1] = "W000";
    normalRoom16[2][1] = "C000";
    normalRoom16[1][1] = "S000";
    normalRoom16[1][9] = "S001";
    normalRoom16[2][2] = "K000";
    normalRoom16[8][1] = "K000";
    normalRoom16[8][9] = "K000";
    normalRoom16[7][4] = "D000";
    normalRoom16[6][7] = "D000";
    normalRoom16[3][6] = "D000";
    
    //vertical
    for (int i = 1; i <= 3; i++) {
     normalRoom16[i][5] = "W000";
    }
    
    for (int i = 7; i <= 9; i++) {
     normalRoom16[i][5] = "W000";
    }
    
    for (int i = 5; i <= 7; i++) {
     normalRoom16[i][3] = "W000";
    }
    
    for (int i = 3; i <= 5; i++) {
     normalRoom16[i][7] = "W000";
    }
    
    //horizontal
    for (int i = 3; i <= 5; i++) {
     normalRoom16[3][i] = "W000";
    }
    
    for (int i = 5; i <= 7; i++) {
     normalRoom16[7][i] = "W000";
    }
    
    for (int i = 1; i <= 3; i++) {
     normalRoom16[5][i] = "W000";
    }
    
    for (int i = 7; i <= 9; i++) {
     normalRoom16[5][i] = "W000";
    }
    
    //17
    String[][] normalRoom17 = new String[11][11];
    //Boundaries
    for (int i = 1; i < normalRoom4.length; i++) {
     for (int j = 0; j < normalRoom4.length; j++) {
      normalRoom17[i][0] = "W000";
      normalRoom17[0][j] = "W000";
      normalRoom17[i][10] = "W000";
      normalRoom17[10][j] = "W000";
      normalRoom17[i][1] = "~~~~";
      normalRoom17[1][j] = "~~~~";
     }
    }
    normalRoom17[1][10] = "W000";
    normalRoom17[1][0] = "W000";
    normalRoom17[10][1] = "W000";
    normalRoom17[2][1] = "C000";
    normalRoom17[1][1] = "S000";
    normalRoom17[1][9] = "S001";
    normalRoom17[6][2] = "K000";
    normalRoom17[8][5] = "K000";
    normalRoom17[5][5] = "D000";
    normalRoom17[4][6] = "D000";
    
    //vertical
    for (int i = 5; i <= 6; i++) {
     normalRoom17[i][4] = "W000";
     normalRoom17[i][6] = "W000";
    }
    
    for (int i = 7; i <= 8; i++) {
     normalRoom17[i][3] = "W000";
     normalRoom17[i][7] = "W000";
    }
    
    //horizontal
    for (int i = 1; i <= 4; i++) {
     normalRoom17[3][i] = "W000";
    }
    
    for (int i = 6; i <= 9; i++) {
     normalRoom17[3][i] = "W000";
    }
    
    for (int i = 1; i <= 2; i++) {
     normalRoom17[9][i] = "W000";
    }
    
    for (int i = 8; i <= 9; i++) {
     normalRoom17[9][i] = "W000";
    }
    
    //18
    String[][] normalRoom18 = new String[11][11];
    //Boundaries
    for (int i = 1; i < normalRoom4.length; i++) {
     for (int j = 0; j < normalRoom4.length; j++) {
      normalRoom18[i][0] = "W000";
      normalRoom18[0][j] = "W000";
      normalRoom18[i][10] = "W000";
      normalRoom18[10][j] = "W000";
      normalRoom18[i][1] = "~~~~";
      normalRoom18[1][j] = "~~~~";
     }
    }
    normalRoom18[1][10] = "W000";
    normalRoom18[1][0] = "W000";
    normalRoom18[10][1] = "W000";
    normalRoom18[1][5] = "W000";
    normalRoom18[9][5] = "W000";
    normalRoom18[8][1] = "C000";
    normalRoom18[9][1] = "S000";
    normalRoom18[9][9] = "S001";
    normalRoom18[1][1] = "K000";
    normalRoom18[1][9] = "K000";
    normalRoom18[8][5] = "D000";
    normalRoom18[2][5] = "D000";
    
    //vertical
    for (int i = 1; i <= 3; i++) {
     normalRoom18[i][2] = "W000";
    }
    
    for (int i = 3; i <= 4; i++) {
     normalRoom18[i][5] = "W000";
    }
    
    for (int i = 6; i <= 7; i++) {
     normalRoom18[i][5] = "W000";
    }
    
    for (int i = 7; i <= 9; i++) {
     normalRoom18[i][8] = "W000";
    }
    
    //horizontal
    for (int i = 2; i <= 5; i++) {
     normalRoom18[3][i] = "W000";
    }
    
    for (int i = 5; i <= 8; i++) {
     normalRoom18[7][i] = "W000";
    }
    
    //19
    String[][] normalRoom19 = new String[11][11];
    //Boundaries
    for (int i = 1; i < normalRoom4.length; i++) {
     for (int j = 0; j < normalRoom4.length; j++) {
      normalRoom19[i][0] = "W000";
      normalRoom19[0][j] = "W000";
      normalRoom19[i][10] = "W000";
      normalRoom19[10][j] = "W000";
      normalRoom19[i][1] = "~~~~";
      normalRoom19[1][j] = "~~~~";
     }
    }
    normalRoom19[1][10] = "W000";
    normalRoom19[1][0] = "W000";
    normalRoom19[10][1] = "W000";
    normalRoom19[2][1] = "C000";
    normalRoom19[1][1] = "S000";
    normalRoom19[1][9] = "S001";
    normalRoom19[8][2] = "K000";
    normalRoom19[8][8] = "K000";
    normalRoom19[6][5] = "D000";
    normalRoom19[5][7] = "D000";
    
    //vertical
    for (int i = 1; i <= 4; i++) {
     normalRoom19[i][5] = "W000";
    }
    
    for (int i = 7; i <= 9; i++) {
     normalRoom19[i][5] = "W000";
    }
    
    //horizontal
    for (int i = 1; i <= 2; i++) {
     normalRoom19[5][i] = "W000";
    }
    
    for (int i = 4; i <= 6; i++) {
     normalRoom19[5][i] = "W000";
    }
    
    for (int i = 8; i <= 9; i++) {
     normalRoom19[5][i] = "W000";
    }
    
    //20
    String[][] normalRoom20 = new String[11][11];
    //Boundaries
    for (int i = 1; i < normalRoom4.length; i++) {
     for (int j = 0; j < normalRoom4.length; j++) {
      normalRoom20[i][0] = "W000";
      normalRoom20[0][j] = "W000";
      normalRoom20[i][10] = "W000";
      normalRoom20[10][j] = "W000";
      normalRoom20[i][1] = "~~~~";
      normalRoom20[1][j] = "~~~~";
     }
    }
    normalRoom20[1][10] = "W000";
    normalRoom20[1][0] = "W000";
    normalRoom20[10][1] = "W000";
    normalRoom20[2][5] = "C000";
    normalRoom20[1][5] = "S000";
    normalRoom20[9][5] = "S001";
    normalRoom20[5][2] = "K000";
    normalRoom20[5][8] = "K000";
    normalRoom20[7][3] = "D000";
    normalRoom20[7][7] = "D000";
    
    normalRoom20[1][1] = "W000";
    normalRoom20[2][2] = "W000";
    normalRoom20[4][4] = "W000";
    normalRoom20[5][5] = "W000";
    normalRoom20[6][6] = "W000";
    normalRoom20[8][8] = "W000";
    normalRoom20[9][9] = "W000";
    normalRoom20[1][9] = "W000";
    normalRoom20[2][8] = "W000";
    normalRoom20[4][6] = "W000";
    normalRoom20[6][4] = "W000";
    normalRoom20[8][2] = "W000";
    normalRoom20[9][1] = "W000";
    //vertical
    
    //horizontal
    
  
  
  //null to ~
  for (int i = 1; i < bossRoom.length; i++) {
   for (int j = 0; j < bossRoom.length; j++) {
    if (bossRoom[i][j] == null) {
     bossRoom[i][j] = "~~~~";
    }
   }
  }
  
  for (int i = 1; i < normalRoom0.length; i++) {
   for (int j = 0; j < normalRoom0.length; j++) {
    if (normalRoom0[i][j] == null) {
     normalRoom0[i][j] = "~~~~";
    }
   }
  }
  
  for (int i = 1; i < normalRoom1.length; i++) {
   for (int j = 0; j < normalRoom1.length; j++) {
    if (normalRoom1[i][j] == null) {
     normalRoom1[i][j] = "~~~~";
    }
   }
  }
  
  for (int i = 1; i < normalRoom2.length; i++) {
   for (int j = 0; j < normalRoom2.length; j++) {
    if (normalRoom2[i][j] == null) {
     normalRoom2[i][j] = "~~~~";
    }
   }
  }
  
  for (int i = 1; i < normalRoom3.length; i++) {
   for (int j = 0; j < normalRoom3.length; j++) {
    if (normalRoom3[i][j] == null) {
     normalRoom3[i][j] = "~~~~";
    }
   }
  }
  
  for (int i = 1; i < normalRoom4.length; i++) {
   for (int j = 0; j < normalRoom4.length; j++) {
    if (normalRoom4[i][j] == null) {
     normalRoom4[i][j] = "~~~~";
    }
   }
  }
  
  for (int i = 1; i < normalRoom5.length; i++) {
   for (int j = 0; j < normalRoom4.length; j++) {
    if (normalRoom5[i][j] == null) {
     normalRoom5[i][j] = "~~~~";
    }
   }
  }
  
  
  for (int i = 1; i < normalRoom6.length; i++) {
   for (int j = 0; j < normalRoom6.length; j++) {
    if (normalRoom6[i][j] == null) {
     normalRoom6[i][j] = "~~~~";
    }
   }
  }
  
  for (int i = 1; i < normalRoom7.length; i++) {
   for (int j = 0; j < normalRoom7.length; j++) {
    if (normalRoom7[i][j] == null) {
     normalRoom7[i][j] = "~~~~";
    }
   }
  }
  
  for (int i = 1; i < normalRoom8.length; i++) {
   for (int j = 0; j < normalRoom8.length; j++) {
    if (normalRoom8[i][j] == null) {
     normalRoom8[i][j] = "~~~~";
    }
   }
  }
  
  for (int i = 1; i < normalRoom9.length; i++) {
   for (int j = 0; j < normalRoom9.length; j++) {
    if (normalRoom9[i][j] == null) {
     normalRoom9[i][j] = "~~~~";
    }
   }
  }
  
  for (int i = 1; i < normalRoom10.length; i++) {
   for (int j = 0; j < normalRoom10.length; j++) {
    if (normalRoom10[i][j] == null) {
     normalRoom10[i][j] = "~~~~";
    }
   }
  }
  
  for (int i = 1; i < normalRoom11.length; i++) {
   for (int j = 0; j < normalRoom11.length; j++) {
    if (normalRoom11[i][j] == null) {
     normalRoom11[i][j] = "~~~~";
    }
   }
  }
  
  for (int i = 1; i < normalRoom12.length; i++) {
   for (int j = 0; j < normalRoom12.length; j++) {
    if (normalRoom12[i][j] == null) {
     normalRoom12[i][j] = "~~~~";
    }
   }
  }
  
  for (int i = 1; i < normalRoom13.length; i++) {
   for (int j = 0; j < normalRoom13.length; j++) {
    if (normalRoom13[i][j] == null) {
     normalRoom13[i][j] = "~~~~";
    }
   }
  }
  
  for (int i = 1; i < normalRoom14.length; i++) {
   for (int j = 0; j < normalRoom14.length; j++) {
    if (normalRoom14[i][j] == null) {
     normalRoom14[i][j] = "~~~~";
    }
   }
  }
  
  for (int i = 1; i < normalRoom15.length; i++) {
   for (int j = 0; j < normalRoom15.length; j++) {
    if (normalRoom15[i][j] == null) {
     normalRoom15[i][j] = "~~~~";
    }
   }
  }
  
  for (int i = 1; i < normalRoom16.length; i++) {
   for (int j = 0; j < normalRoom16.length; j++) {
    if (normalRoom16[i][j] == null) {
     normalRoom16[i][j] = "~~~~";
    }
   }
  }
  
  for (int i = 1; i < normalRoom17.length; i++) {
   for (int j = 0; j < normalRoom17.length; j++) {
    if (normalRoom17[i][j] == null) {
     normalRoom17[i][j] = "~~~~";
    }
   }
  }
  
  for (int i = 1; i < normalRoom18.length; i++) {
   for (int j = 0; j < normalRoom18.length; j++) {
    if (normalRoom18[i][j] == null) {
     normalRoom18[i][j] = "~~~~";
    }
   }
  }
  
  for (int i = 1; i < normalRoom19.length; i++) {
   for (int j = 0; j < normalRoom19.length; j++) {
    if (normalRoom19[i][j] == null) {
     normalRoom19[i][j] = "~~~~";
    }
   }
  }
  
  for (int i = 1; i < normalRoom20.length; i++) {
   for (int j = 0; j < normalRoom20.length; j++) {
    if (normalRoom20[i][j] == null) {
     normalRoom20[i][j] = "~~~~";
    }
   }
  }
  
  String[][] [] pool1 = {normalRoom0, normalRoom2, normalRoom3, normalRoom4, normalRoom5, normalRoom6, normalRoom7, normalRoom8, normalRoom9, normalRoom10, normalRoom11};
  String[][] [] pool2 = {normalRoom2, normalRoom3, normalRoom4, normalRoom5, normalRoom6, normalRoom7, normalRoom8, normalRoom9, normalRoom10, normalRoom11, normalRoom12};
  String[][] [] pool3 = {normalRoom3, normalRoom4, normalRoom5, normalRoom6, normalRoom7, normalRoom8, normalRoom9, normalRoom10, normalRoom11, normalRoom12, normalRoom13};
  String[][] [] pool4 = {normalRoom4, normalRoom5, normalRoom6, normalRoom7, normalRoom8, normalRoom9, normalRoom10, normalRoom11, normalRoom12, normalRoom13, normalRoom14};
  String[][] [] pool5 = {normalRoom5, normalRoom6, normalRoom7, normalRoom8, normalRoom9, normalRoom10, normalRoom11, normalRoom12, normalRoom13, normalRoom14, normalRoom15};
  String[][] [] pool6 = {normalRoom6, normalRoom7, normalRoom8, normalRoom9, normalRoom10, normalRoom11, normalRoom12, normalRoom13, normalRoom14, normalRoom15, normalRoom16};
  String[][] [] pool7 = {normalRoom7, normalRoom8, normalRoom9, normalRoom10, normalRoom11, 
    normalRoom12, normalRoom13, normalRoom14, normalRoom15, normalRoom16, normalRoom17};
  String[][] [] pool8 = {normalRoom8, normalRoom9, normalRoom10, normalRoom11, 
    normalRoom12, normalRoom13, normalRoom14, normalRoom15, normalRoom16, normalRoom17, 
    normalRoom18};
  String[][] [] pool9 = {normalRoom9, normalRoom10, normalRoom11, 
    normalRoom12, normalRoom13, normalRoom14, normalRoom15, normalRoom16, normalRoom17, 
    normalRoom18, normalRoom19};
  String[][] [] pool10 = {normalRoom10, normalRoom11, 
    normalRoom12, normalRoom13, normalRoom14, normalRoom15, normalRoom16, normalRoom17, 
    normalRoom18, normalRoom19, normalRoom20, normalRoom0};
  String[][] [] pool11 = {normalRoom0, normalRoom2, normalRoom3, normalRoom4, 
    normalRoom6, normalRoom7, normalRoom8, normalRoom9, normalRoom10, normalRoom11, 
    normalRoom12, normalRoom13, normalRoom14, normalRoom15, normalRoom16, normalRoom17, 
    normalRoom18, normalRoom19, normalRoom20};
  //Different circumstances
  if (level == currLevel) {
   return bossRoom;
  }
  
  else {
    if (currLevel == 1) {
    return normalRoom1;
   }
   
   else if ((seed + currLevel) % 10 == 1) {
    return randomPool(pool1);
   }
   
   else if ((seed + currLevel) % 10 == 2) {
    return randomPool(pool2);
   }
   
   else if ((seed + currLevel) % 10 == 3) {
    return randomPool(pool3);
   }
   
   else if ((seed + currLevel) % 10 == 4) {
    return randomPool(pool4);
   }
    
   else if ((seed + currLevel) % 10 == 5) {
    return randomPool(pool5);
   }
   
   else if ((seed + currLevel) % 10 == 6) {
    return randomPool(pool6);
   }
   
   else if ((seed + currLevel) % 10 == 7) {
    return randomPool(pool7);
   }
   
   else if ((seed + currLevel) % 10 == 8) {
    return randomPool(pool8);
   }
   
   else if ((seed + currLevel) % 10 == 9) {
    return randomPool(pool9);
   }
   
   else if ((seed + currLevel) % 10 == 0) {
    return randomPool(pool11);
   }
   
   else {
    return randomPool(pool10);
   }
  }
 }
 
 public static String[][] GenerateMonster(String[][] oldmap, int CurrentLevel){
  String Monster1;
  String Monster2;
  String Monster3;
  String Monster4;
  
  String FirstNumber;
  String SecondNumber = "0";
  String ThirdNumber;
  
  ArrayList<String> Candidate = new ArrayList<String>();
  
  FirstNumber = Integer.toString(difficulty);
  
  /*
   * 
   * 
   */
  if(CurrentLevel == level){
   ThirdNumber = Integer.toString((int)(8 + seed%2));  //choose one boss randomly from two
   Monster1 = "M"+FirstNumber+"0"+ThirdNumber;
   Monster2 = "~~~~";
   Monster3 = "~~~~";
   Monster4 = "~~~~";
  }
  else{
   if(CurrentLevel <= level/3){
    for(int i = 0; i < Math.abs((level/3) - CurrentLevel); i++){
     Candidate.add("0");
     Candidate.add("1");
    }
   }
   if(CurrentLevel > level/3){
    for(int i = 0; i < level-CurrentLevel; i++){
     Candidate.add("0");
     Candidate.add("1");
    }
   }
   if(CurrentLevel <= 0.75 * level && CurrentLevel >= 0.25 * level){
    for(int i = 0; i < Math.abs(0.75 * level - CurrentLevel); i++){
     Candidate.add("2");
    }
   }
   if(CurrentLevel >= 0.25 * level){
    for(int i = 0; i < level-CurrentLevel; i++){
     Candidate.add("3");
    }
   }
   if(CurrentLevel >= 2*level/5){
    for(int i = 0; i < 0.8*level; i++){
     Candidate.add("4");
    }
   }
   if(CurrentLevel >= 0.5 * level){
    for(int i = 0; i < level; i++){
     Candidate.add("5");
    }
   }
   if(CurrentLevel >= level * 2 / 3){
    for(int i = 0; i < level/5; i++){
     Candidate.add("6");
    }
   }
   if(CurrentLevel >= 0.8*level){
    for(int i = (int) (0.8*level); i < level; i++){
     Candidate.add("7");
    }
   }
   
   
   /*
    * randomly choose 4 monsters from the candidate list with different probabilities
    */
   Monster1 = "M"+FirstNumber + SecondNumber + Candidate.get(Integer.parseInt(StringSeed.substring(0, 3))%Candidate.size());
   Monster2 = "M"+FirstNumber + SecondNumber + Candidate.get(Integer.parseInt(StringSeed.substring(1, 4))%Candidate.size());
   Monster3 = "M"+FirstNumber + SecondNumber + Candidate.get(Integer.parseInt(StringSeed.substring(2, 5))%Candidate.size());
   Monster4 = "M"+FirstNumber + SecondNumber + Candidate.get(Integer.parseInt(StringSeed.substring(3, 6))%Candidate.size());   
  }
  
  //System.out.println(Monster1);
  //System.out.println(Monster2);
  //System.out.println(Monster3);
  //System.out.println(Monster4);
  
  
  /*
   * After generated 4 monsters for this floor, we should give each of them a location
   */
  int doorNumber = 0;
  if(CurrentLevel != level){
   for(int i = 0; i < 11; i++){
    for(int j = 0; j < 11; j++){
     if(oldmap[i][j].equals("D000")){
      doorNumber++;
     }
    }
   }
  }
  
  int upX = 10;
  int upY = 10;
  int downX = 1;
  int downY = 1;
  
  for(int i = 0; i < 11; i++){
   for(int j = 0; j < 11; j++){
    if(oldmap[i][j].equals("S000")){
     downX = i;
     downY = j;
    }
    
    if(oldmap[i][j].equals("S001")){
     upX = i;
     upY = j;
    }
   }
  }
  
  /*
   * If we have one door at this floor
   */
  
  if(doorNumber == 1 && CurrentLevel != level && CurrentLevel != 0){
   for(int i = 0; i < 11; i++){
    for(int j = 0; j < 11; j++){
     
     //generate monster1 (block the door)
     if(oldmap[i][j].equals("D000")){
      if(intseed%4 == 0 && oldmap[i-1][j].equals("~~~~")){
       oldmap[i-1][j] = Monster1;
      }
      else if(intseed%4 == 1 && oldmap[i][j+1].equals("~~~~")){
       oldmap[i][j+1] = Monster1;
      }       
      else if(intseed%4 == 2 && oldmap[i+1][j].equals("~~~~")){
       oldmap[i+1][j] = Monster1;
      }
      else if(intseed%4 == 3 && oldmap[i][j-1].equals("~~~~")){
       oldmap[i][j-1] = Monster1;
      }
      else{
       if(oldmap[i-1][j].equals("~~~~")){
        oldmap[i-1][j] = Monster1;
       }
       else if(oldmap[i][j+1].equals("~~~~")){
        oldmap[i][j+1] = Monster1;
       }
       else if(oldmap[i+1][j].equals("~~~~")){
        oldmap[i+1][j] = Monster1;
       }
       else{
        oldmap[i][j-1] = Monster1;
       }
      }
      i+=11;
      j+=11;
     }
    }
   }
   
   //generate monster2 (block the down stair)
   if(downX - 1 >= 1){
    downX--;
    if(downX - 1 >= 1 && oldmap[downX-1][downY].equals("~~~~")){
     downX--;
     oldmap[downX][downY] = Monster2;
    }
    else if(downY - 1 >= 1 && oldmap[downX][downY-1].equals("~~~~")){
     downY--;
     oldmap[downX][downY] = Monster2;
    }
    else if(downY + 1 <= 9 && oldmap[downX][downY+1].equals("~~~~")){
     downY++;
     oldmap[downX][downY] = Monster2;
    }
   }
   else if(downX + 1 <= 9){
    downX++;
    if(downX + 1 <= 9 && oldmap[downX+1][downY].equals("~~~~")){
     downX++;
     oldmap[downX][downY] = Monster2;
    }
    else if(downY - 1 >= 1 && oldmap[downX][downY-1].equals("~~~~")){
     downY--;
     oldmap[downX][downY] = Monster2;
    }
    else if(downY + 1 <= 9 && oldmap[downX][downY+1].equals("~~~~")){
     downY++;
     oldmap[downX][downY] = Monster2;
    }
   }
   else if(downY + 2 <= 9 && oldmap[downX][downY+2].equals("~~~~")){
    downY += 2;
    oldmap[downX][downY] = Monster2;
   }
   else if(downY - 2 >= 1 && oldmap[downX][downY-2].equals("~~~~")){
    downY -= 2;
    oldmap[downX][downY] = Monster2;
   }
   else
    System.out.println("Fail to generate Monster 2");
   
   
   //generate monster3 (block the up stair)
   if(upX - 1 >= 1){
    upX--;
    if(upX - 1 >= 1 && oldmap[upX-1][upY].equals("~~~~")){
     upX--;
     oldmap[upX][upY] = Monster3;
    }
    else if(upY - 1 >= 1 && oldmap[upX][upY-1].equals("~~~~")){
     upY--;
     oldmap[upX][upY] = Monster3;
    }
    else if(upY + 1 <= 9 && oldmap[upX][upY+1].equals("~~~~")){
     upY++;
     oldmap[upX][upY] = Monster3;
    }
   }
   else if(upX + 1 <= 9){
    upX++;
    if(upX + 1 <= 9 && oldmap[upX+1][upY].equals("~~~~")){
     upX++;
     oldmap[upX][upY] = Monster3;
    }
    else if(upY - 1 >= 1 && oldmap[upX][upY-1].equals("~~~~")){
     upY--;
     oldmap[upX][upY] = Monster3;
    }
    else if(upY + 1 <= 9 && oldmap[upX][upY+1].equals("~~~~")){
     upY++;
     oldmap[upX][upY] = Monster3;
    }
   }
   else if(upY + 2 <= 9 && oldmap[upX][upY+2].equals("~~~~")){
    upY += 2;
    oldmap[upX][upY] = Monster3;
   }
   else if(upY - 2 >= 1 && oldmap[upX][upY-2].equals("~~~~")){
    upY -= 2;
    oldmap[upX][upY] = Monster3;
   }
   else
    System.out.println("Fail to generate Monster 3");
   
   
   //generate monster4 (random generation)
   int M4X = intseed%10 + (intseed/10%10)*10 + (intseed/100%10)*100;
   int M4Y = (intseed%10)*100 + (intseed/10%10)*10 + intseed/100%10;
   
   //System.out.println(M4X%11);
   //System.out.println(M4Y%11);
   
   
   if(oldmap[M4X%11][M4Y%11].equals("~~~~")){
    oldmap[M4X%11][M4Y%11] = Monster4;
   }
   else{
    for(int i = 0; i < 4; i++){
     for(int j = 0; j < 4; j++){
      if(oldmap[5+i][5+j].equals("~~~~")){
       oldmap[5+i][5+j] = Monster4;
       i+=5;
       j+=5;
      }
      else if(oldmap[5-i][5-j].equals("~~~~")){
       oldmap[5-i][5-j] = Monster4;
       i+=5;
       j+=5;
      }
     }
    }
   }
  }
  
  
  /*
   * If we have at least two doors at this floor
   */
  
  
  if(doorNumber >= 2 && CurrentLevel != level && CurrentLevel != 0){
   for(int i = 0; i < 11; i++){
    for(int j = 0; j < 11; j++){
     
     //generate monster1 (block the first door)
     if(oldmap[i][j].equals("D000")){
      if(intseed%4 == 0 && oldmap[i-1][j].equals("~~~~")){
       oldmap[i-1][j] = Monster1;
      }
      else if(intseed%4 == 1 && oldmap[i][j+1].equals("~~~~")){
       oldmap[i][j+1] = Monster1;
      }       
      else if(intseed%4 == 2 && oldmap[i+1][j].equals("~~~~")){
       oldmap[i+1][j] = Monster1;
      }
      else if(intseed%4 == 3 && oldmap[i][j-1].equals("~~~~")){
       oldmap[i][j-1] = Monster1;
      }
      else{
       if(oldmap[i-1][j].equals("~~~~")){
        oldmap[i-1][j] = Monster1;
       }
       else if(oldmap[i][j+1].equals("~~~~")){
        oldmap[i][j+1] = Monster1;
       }
       else if(oldmap[i+1][j].equals("~~~~")){
        oldmap[i+1][j] = Monster1;
       }
       else{
        oldmap[i][j-1] = Monster1;
       }
      }
      i+=11;
      j+=11;
     }
    }
   }
   
   for(int i1 = 0; i1 < 10; i1++){
    for(int j1 = 0; j1 < 10; j1++){
     //generate monster2 (block the second door)
     if(oldmap[9-i1][9-j1].equals("D000")){
      if(intseed%4 == 0 && oldmap[9-i1-1][9-j1].equals("~~~~")){
       oldmap[9-i1-1][9-j1] = Monster2;
      }
      else if(intseed%4 == 1 && oldmap[9-i1][9-j1+1].equals("~~~~")){
       oldmap[9-i1][9-j1+1] = Monster2;
      }       
      else if(intseed%4 == 2 && oldmap[9-i1+1][9-j1].equals("~~~~")){
       oldmap[9-i1+1][9-j1] = Monster2;
      }
      else if(intseed%4 == 3 && oldmap[9-i1][9-j1-1].equals("~~~~")){
       oldmap[9-i1][9-j1-1] = Monster2;
      }
      else{
       if(oldmap[9-i1-1][9-j1].equals("~~~~")){
        oldmap[9-i1-1][9-j1] = Monster2;
       }
       else if(oldmap[9-i1][9-j1+1].equals("~~~~")){
        oldmap[9-i1][9-j1+1] = Monster2;
       }
       else if(oldmap[9-i1+1][9-j1].equals("~~~~")){
        oldmap[9-i1+1][9-j1] = Monster2;
       }
       else{
        oldmap[9-i1][9-j1-1] = Monster2;
       }
      }
      i1+=11;
      j1+=11;
     }
    }
   }
   
   //generate monster3 (block the down stair)
   if(downX - 1 >= 1){
    downX--;
    if(downX - 1 >= 1 && oldmap[downX-1][downY].equals("~~~~")){
     downX--;
     oldmap[downX][downY] = Monster3;
    }
    else if(downY - 1 >= 1 && oldmap[downX][downY-1].equals("~~~~")){
     downY--;
     oldmap[downX][downY] = Monster3;
    }
    else if(downY + 1 <= 9 && oldmap[downX][downY+1].equals("~~~~")){
     downY++;
     oldmap[downX][downY] = Monster3;
    }
   }
   else if(downX + 1 <= 9){
    downX++;
    if(downX + 1 <= 9 && oldmap[downX+1][downY].equals("~~~~")){
     downX++;
     oldmap[downX][downY] = Monster3;
    }
    else if(downY - 1 >= 1 && oldmap[downX][downY-1].equals("~~~~")){
     downY--;
     oldmap[downX][downY] = Monster3;
    }
    else if(downY + 1 <= 9 && oldmap[downX][downY+1].equals("~~~~")){
     downY++;
     oldmap[downX][downY] = Monster3;
    }
   }
   else if(downY + 2 <= 9 && oldmap[downX][downY+2].equals("~~~~")){
    downY += 2;
    oldmap[downX][downY] = Monster3;
   }
   else if(downY - 2 >= 1 && oldmap[downX][downY-2].equals("~~~~")){
    downY -= 2;
    oldmap[downX][downY] = Monster3;
   }
   else
    System.out.println("Fail to generate Monster 3");
   
   
   //generate monster4 (block the up stair)
   if(upX - 1 >= 1){
    upX--;
    if(upX - 1 >= 1 && oldmap[upX-1][upY].equals("~~~~")){
     upX--;
     oldmap[upX][upY] = Monster4;
    }
    else if(upY - 1 >= 1 && oldmap[upX][upY-1].equals("~~~~")){
     upY--;
     oldmap[upX][upY] = Monster4;
    }
    else if(upY + 1 <= 9 && oldmap[upX][upY+1].equals("~~~~")){
     upY++;
     oldmap[upX][upY] = Monster4;
    }
   }
   else if(upX + 1 <= 9){
    upX++;
    if(upX + 1 <= 9 && oldmap[upX+1][upY].equals("~~~~")){
     upX++;
     oldmap[upX][upY] = Monster4;
    }
    else if(upY - 1 >= 1 && oldmap[upX][upY-1].equals("~~~~")){
     upY--;
     oldmap[upX][upY] = Monster4;
    }
    else if(upY + 1 <= 9 && oldmap[upX][upY+1].equals("~~~~")){
     upY++;
     oldmap[upX][upY] = Monster4;
    }
   }
   else if(upY + 2 <= 9 && oldmap[upX][upY+2].equals("~~~~")){
    upY += 2;
    oldmap[upX][upY] = Monster4;
   }
   else if(upY - 2 >= 1 && oldmap[upX][upY-2].equals("~~~~")){
    upY -= 2;
    oldmap[upX][upY] = Monster4;
   }
   else
    System.out.println("Fail to generate Monster 4");
   
  }
  
  /*
   * Boss Fight Floor
   */
  if(CurrentLevel == level){
   oldmap[5][5] = Monster1;
  }
  
 
  
  //for (int i=0; i<11; i++){
   //for (int j=0; j<11; j++){
    //if(j == 10)
     //System.out.println(oldmap[i][j]);
    //else
     //System.out.print(oldmap[i][j]);
   //}
  //}
  
  return oldmap;
 }
 
}
