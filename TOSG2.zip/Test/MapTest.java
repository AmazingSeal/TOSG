import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MapTest {

	@Test
	/**
	 * This test tests whether the output of is a String[][]
	 */
	void test() {
		MapGeneratorAndMonsterGenerator test = new MapGeneratorAndMonsterGenerator();
		String[][] output1 = test.createMap(9494, 1);
		String[][] output2 = test.createMap(9494, 30);
		String[][] output3 = test.createMap(9494, 50);
		String[][] output4 = test.createMap(244244244, 1);
		String[][] output5 = test.createMap(244244244, 30);
		String[][] output6 = test.createMap(244244244, 50);
		assertTrue(output1 instanceof String[][]);
		assertTrue(output2 instanceof String[][]);
		assertTrue(output3 instanceof String[][]);
		assertTrue(output4 instanceof String[][]);
		assertTrue(output5 instanceof String[][]);
		assertTrue(output6 instanceof String[][]);
	}
}
