TOSG folder contains the code
test contains test for test map
TestMap folder in TOSG folder also contains test