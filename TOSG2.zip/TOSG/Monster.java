import javax.swing.Spring;


public class Monster {
 public int HP;
 public int ATK;
 public int DEF;
 public String name;
 public Monster(int difficulty, int level, int num){
  name = "M" + difficulty + "0" + num;
  switch (num) {
  case 0: // slime
   if (difficulty == 0)      {this.HP = 10; this.ATK = 10; this.DEF = 1;}
   else if (difficulty == 1) {this.HP = 12; this.ATK = 12; this.DEF = 2;}
   else                      {this.HP = 15; this.ATK = 15; this.DEF = 3;}
   break;
  case 1: // bat
   if (difficulty == 0)      {this.HP = 20; this.ATK = 12; this.DEF = 1;}
   else if (difficulty == 1) {this.HP = 25; this.ATK = 15; this.DEF = 2;}
   else                      {this.HP = 25; this.ATK = 17; this.DEF = 3;}
   break;
  case 2: // skeleton
   if (difficulty == 0)      {this.HP = 30; this.ATK = 14; this.DEF = 2;}
   else if (difficulty == 1) {this.HP = 32; this.ATK = 17; this.DEF = 3;}
   else                      {this.HP = 35; this.ATK = 18; this.DEF = 4;}
   break;
  case 3: // magician
   if (difficulty == 0)      {this.HP = 50; this.ATK = 16; this.DEF = 2;}
   else if (difficulty == 1) {this.HP = 55; this.ATK = 18; this.DEF = 3;}
   else                      {this.HP = 58; this.ATK = 20; this.DEF = 4;}
   break;
  case 4: // zombie
   if (difficulty == 0)      {this.HP = 200; this.ATK = 60; this.DEF = 5;}
   else if (difficulty == 1) {this.HP = 210; this.ATK = 62; this.DEF = 5;}
   else                      {this.HP = 220; this.ATK = 65; this.DEF = 6;}
   break;
  case 5: // knight
   if (difficulty == 0)      {this.HP = 150; this.ATK = 200; this.DEF = 40;}
   else if (difficulty == 1) {this.HP = 160; this.ATK = 210; this.DEF = 40;}
   else                      {this.HP = 170; this.ATK = 220; this.DEF = 40;}
   break;
  case 6: // dark knight
   if (difficulty == 0)      {this.HP = 150; this.ATK = 300; this.DEF = 60;}
   else if (difficulty == 1) {this.HP = 160; this.ATK = 310; this.DEF = 60;}
   else                      {this.HP = 170; this.ATK = 330; this.DEF = 60;}
   break;
  case 7: // Caster
   if (difficulty == 0)      {this.HP = 300; this.ATK = 500; this.DEF = 80;}
   else if (difficulty == 1) {this.HP = 320; this.ATK = 520; this.DEF = 80;}
   else                      {this.HP = 350; this.ATK = 540; this.DEF = 80;}
   break;
  case 8: // Blood Moon
   if (difficulty == 0)      {this.HP = 1200; this.ATK = 700; this.DEF = 200;}
   else if (difficulty == 1) {this.HP = 1350; this.ATK = 720; this.DEF = 200;}
   else                      {this.HP = 1500; this.ATK = 750; this.DEF = 210;}
   break;
  case 9: // dragon
   if (difficulty == 0)      {this.HP = 1500; this.ATK = 600; this.DEF = 250;}
   else if (difficulty == 1) {this.HP = 1600; this.ATK = 600; this.DEF = 260;}
   else                      {this.HP = 1700; this.ATK = 600; this.DEF = 280;}
   break;
  }
 }
 
 public String toString(){
  return name;
 }
 
 public Monster clone(){
  return new Monster(name.charAt(1) - '0', name.charAt(2) - '0', name.charAt(3) - '0');
 }
}
