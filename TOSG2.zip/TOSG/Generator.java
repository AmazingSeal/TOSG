import java.awt.event.*;
import java.awt.*;
import javax.swing.*;
import java.io.*;

class Generator{
  
  JComboBox<String> diffList;
  JComboBox<String> levelList;
  JTextArea seed;
  String s;
  
  public void init(){
    File temp = new File("./map");
    File[] tempfiles = temp.listFiles();
    if (tempfiles != null){
      for (File f: tempfiles){
        f.delete();
      }
    }
  }
  
  
  
  
   public static void main(String[] args){
    String[] diff = { "Easy", "Hard", "Hell" };
    String[] level = { "15", "30", "45" };
    Generator gen = new Generator();       
    JFrame frame = new JFrame("Tower of the Sorcerer");
    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    JPanel p = new JPanel(new FlowLayout());
    
    /* get seed */
    gen.s = "";
    for (int i = 0; i < 8; i++){
      int r = (int)Math.floor(Math.random()*62);
      if (r < 10)
        gen.s = gen.s+ Character.toString((char)(r+48));
      else if (r >=10 && r <36)
        gen.s = gen.s+ Character.toString((char)(r+55));
      else
        gen.s = gen.s+ Character.toString((char)(r+61));
    }
     
    
    JLabel difft = new JLabel("Difficulty:");
    difft.setFont(new Font("Courier New",Font.PLAIN, 23));
    difft.setPreferredSize(new Dimension(200,50));
    difft.setFont(new Font("Courier New",Font.PLAIN, 23));
    
    JLabel levelt = new JLabel("Level:");
    levelt.setFont(new Font("Courier New",Font.PLAIN, 23));
    levelt.setPreferredSize(new Dimension(200,50));
    levelt.setFont(new Font("Courier New",Font.PLAIN, 23));
    
    JLabel seedt = new JLabel("Seed:");
    seedt.setFont(new Font("Courier New",Font.PLAIN, 23));
    seedt.setPreferredSize(new Dimension(200,50));
    seedt.setFont(new Font("Courier New",Font.PLAIN, 23));
    
    gen.diffList = new JComboBox<String>(diff);
    gen.diffList.setPreferredSize(new Dimension(150,50));
    gen.diffList.setFont(new Font("Courier New",Font.PLAIN, 23));
    gen.diffList.setSelectedIndex(1);
    
    gen.levelList = new JComboBox<String>(level);
    gen.levelList.setPreferredSize(new Dimension(150,50));
    gen.levelList.setFont(new Font("Courier New",Font.PLAIN, 23));
    gen.levelList.setSelectedIndex(1);
    
    gen.seed = new JTextArea(gen.s);
    gen.seed.setPreferredSize(new Dimension(150,50));
    gen.seed.setFont(new Font("Courier New",Font.PLAIN, 23));
    
    JButton button = new JButton("Play");
    button.setPreferredSize(new Dimension(100,50));
    button.setFont(new Font("Courier New",Font.PLAIN, 23));
    
    button.addActionListener(new ActionListener() {
      @Override
      public void actionPerformed(ActionEvent e) {
        try {
          /* send to config file and start game */
          File file = new File("config.txt");
          if (!file.exists()) 
            file.createNewFile();
          FileWriter fileWriter = new FileWriter(file);
          fileWriter.write("");
          fileWriter.flush();
          fileWriter.close();
          
          FileWriter fw = new FileWriter(file);
          String text = gen.seed.getText();
          boolean t = true;
          if (text.length() == 8){
            int te;
            for (int i = 0; i<8; i++){
              te = (int) text.charAt(i); 
              if ((te<48) || (te > 57 && te < 65) ||(te > 90 && te < 128) ||(te >122))
                t = false;
            }
          }else
            t = false;
          if (t)
            fw.write(text);
          else
            fw.write(gen.s);
          fw.write("\r\n");
          fw.write(String.valueOf((gen.levelList.getSelectedIndex()+1)*15));
          fw.write("\r\n");
          fw.write(String.valueOf((gen.diffList.getSelectedIndex())));
          
          fw.close();
          
        } catch (IOException exp) {
          exp.printStackTrace();
        }
        gen.init();
        MMG.main(args);
        try{
          MapItemGenerator.main(args);
        }
        catch (Exception exp) {
        }
        frame.dispose();
        Game.main(args);
      }
    });
    
    
    
    p.add(difft);
    difft.setLabelFor(gen.diffList);
    p.add(gen.diffList);
    p.add(levelt);
    levelt.setLabelFor(gen.levelList);
    p.add(gen.levelList);
    p.add(seedt);
    seedt.setLabelFor(gen.seed);
    p.add(gen.seed);
    p.add(button);
   

    frame.add(p);
    frame.setSize(400,300);
    frame.setVisible(true);
    
  }
}