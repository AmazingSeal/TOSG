
public class Item {
 public int HP;
 public int ATK;
 public int DEF;
 public String name;
 
 public Item(String num){
  name = num;
  switch (num) {
  case "P000": 
   HP = 20; ATK = 0; DEF = 0; break;
  case "P001": 
   HP = 50; ATK = 0; DEF = 0; break;
  case "P002": 
   HP = 100; ATK = 0; DEF = 0; break;
  case "P003": 
   HP = 200; ATK = 0; DEF = 0; break;
  case "P004": 
   HP = 500; ATK = 0; DEF = 0; break;
  case "I000": 
   HP = 0; ATK = 5; DEF = 0; break;
  case "I001": 
   HP = 0; ATK = 10; DEF = 0; break;
  case "I002": 
   HP = 0; ATK = 20; DEF = 0; break;
  case "I003": 
   HP = 0; ATK = 50; DEF = 0; break;
  case "I004": 
   HP = 0; ATK = 100; DEF = 0; break;
  case "I010": 
   HP = 0; ATK = 0; DEF = 5; break;
  case "I011": 
   HP = 0; ATK = 0; DEF = 10; break;
  case "I012": 
   HP = 0; ATK = 0; DEF = 20; break;
  case "I013": 
   HP = 0; ATK = 0; DEF = 50; break;
  case "I014": 
   HP = 0; ATK = 0; DEF = 100; break;
  }
 }
 
 public String toString() {
  return name + " " + HP + " " + ATK + " " + DEF;
 }
}