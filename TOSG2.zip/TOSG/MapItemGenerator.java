import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class MapItemGenerator {
 private Monster[] monsterList = new Monster[4]; // need Monster type
 private int[][] monsterPosition = new int[4][2];
 private int monsterCount;
 private boolean [][] visited;
 private static int randomCount = 0;
 private long key;
 private boolean foundStair;
 public int HP;
 public int ATK;
 public int DEF;
 public int level;
 private boolean needATK = false;
 
 public MapItemGenerator(int key){
  visited = new boolean[11][11];
  this.key = key;
 }
 
 
 public String[][] ItemGenerator(String[][] originalMap, int HPenter, int ATKenter, int DEFenter) throws InterruptedException {
  this.HP = HPenter;
  this.ATK  =ATKenter;
  this.DEF = DEFenter;
  String[][] map = new String[11][11];
  for (int i = 0; i < originalMap.length; i++)
   for (int j = 0; j < originalMap[i].length; j++)
    map[i][j] = originalMap[i][j].toString();
  int stairDowni = -1;
  int stairDownj = -1;
  // get the level and difficulty
  for (int i = 0; i < map.length; i++){
   for (int j = 0; j < map[i].length; j++){ // here, both i and j are supposed to be from 0 to 10
    if (map[i][j].equals("S000")) {stairDowni = i; stairDownj = j;}    
   }
  }
  
  
  foundStair = false;
  for (int i = 0; i < visited.length; i++)
   for (int j = 0; j < visited[i].length; j++){
    visited[i][j] = false;
   }
  visited[stairDowni][stairDownj] = true;
  
  while (!foundStair) {
   // visit all possible points
   for (int i = 0; i < visited.length; i++)
    for (int j = 0; j < visited[i].length; j++){
     visited[i][j] = false;
    }
   visited[stairDowni][stairDownj] = true;
   goThroughMap(map, stairDowni, stairDownj);
   // here, all position visible is marked, and monsters meetable are stored
   ArrayList<String> neededItems = itemsNeeded(HP, ATK, DEF);
   // here, we get a linked list of items required to beat the monsters
   if (foundStair) {neededItems = new ArrayList<String>(); neededItems.add("P000"); neededItems.add(randomItemType() + "0");}
   // if you can go to the stair without touching any monster, provide only one basic item as reward
   
   Object[] neededItemsArray = neededItems.toArray();
   
   for (int index = 0; index < neededItemsArray.length; index++){
    boolean itemAssigned = false;
    for (int i = 0; i < visited.length && !itemAssigned; i++){
     Item addedItem = new Item(neededItemsArray[index].toString());
     for (int j = 0; j < visited[i].length && !itemAssigned; j++){
       randomCount++;
      if (visited[i][j] && originalMap[i][j].equals("~~~~") && (key+randomCount++)%10 == 0){
       originalMap[i][j] = addedItem.name;
       HP += addedItem.HP;
       ATK += addedItem.ATK;
       DEF += addedItem.DEF;
       itemAssigned = true;
      }
     }
    }
   }
   
   // delete monsters met before
   for (int i = 0; i < monsterPosition.length; i++){
    if (monsterList[i] != null){
     map[monsterPosition[i][0]][monsterPosition[i][1]] = "~~~~";
     fight(monsterList[i]);
    }
   }
      
   monsterCount = 0;
   monsterList = new Monster[4];
   monsterPosition = new int[4][2];

   
  }
  
  return originalMap;
 }
 
 // visit all points reachable without beating any monster
 // return whether you can reach the stair to the next level.
 public boolean goThroughMap(String[][] map, int i, int j) throws InterruptedException {
  boolean found = false;
  visited[i][j] = true;
  if (map[i][j].charAt(0) == 'W') {}
  else if (map[i][j].charAt(0) == 'M') {
   visited[i][j] = true;
   monsterList[monsterCount] = new Monster(map[i][j].charAt(1) - '0', 
             map[i][j].charAt(2) - '0', 
             map[i][j].charAt(3) - '0');
   monsterPosition[monsterCount][0] = i;
   monsterPosition[monsterCount][1] = j;
   monsterCount++;
  }
  else if (map[i][j].equals("S001")) 
   {foundStair = true; return true;}
  else {
   
   if (i < 10 && !visited[i+1][j])
    found = goThroughMap(map, i + 1, j);
   if (j < 10 && !visited[i][j+1])
    found = goThroughMap(map, i, j+1);
   if (i > 0 && !visited[i-1][j])
    found = goThroughMap(map, i - 1, j);
   if (j > 0 && !visited[i][j-1])
    found = goThroughMap(map, i, j -1);
  }
  return found;
 }
 
 // based on the monsters meet and character's status, return an array of strings representing items needed
 public ArrayList<String> itemsNeeded(int HP, int ATK, int DEF) {
  ArrayList<String> needed = new ArrayList<String>();
  int iniHP2 = HP;
  int iniATK2 = ATK;
  int iniDEF2 = DEF;
  while (!beatable(HP, ATK, DEF))
  {
   String[] nextTwoItemsType = new String[2];
   nextTwoItemsType[0] = "P00";
   nextTwoItemsType[1] = randomItemType();
   char[] nextTwoItemsLevel = new char[2];
   nextTwoItemsLevel[0] = '0';
   nextTwoItemsLevel[1] = '0';
   Item[] nextTwoItems = new Item[2];
   nextTwoItems[0] = new Item(nextTwoItemsType[0] + nextTwoItemsLevel[0]);
   nextTwoItems[1] = new Item(nextTwoItemsType[1] + nextTwoItemsLevel[1]);

   Object[] neededArray = needed.toArray();
   for (int i = 0; i < neededArray.length; i++){
    Item added = new Item(neededArray[i].toString());
    iniHP2 += added.HP;
    iniATK2 += added.ATK;
    iniDEF2 += added.DEF;
   }
   
   int count = 0;
   while (!beatable(HP, ATK, DEF) && (nextTwoItemsLevel[0] != '4' && nextTwoItemsLevel[1] != '4')){
    // the old item is not enough to fight with monsters
    nextTwoItemsLevel[count%2] = (char)(nextTwoItemsLevel[count%2] + 1);
    
    
    // add new items
    nextTwoItems[count%2] = new Item(nextTwoItemsType[count%2] + nextTwoItemsLevel[count%2]);
    
    HP = iniHP2 + nextTwoItems[0].HP;
    ATK = iniATK2 + nextTwoItems[1].ATK;
    DEF = iniDEF2 + nextTwoItems[1].DEF; 
    
    count++;
   }
   
   needed.add(nextTwoItems[0].name);
   needed.add(nextTwoItems[1].name);
   
  }
  return needed;
 }
 
 // whether a character with particular HP, ATK, and DEF can beat the monster
 public boolean beatable(int HP, int ATK, int DEF) {
  if (monsterList == null) return true;
  
  for (int i = 0; i < monsterList.length; i++){
   if (monsterList[i] != null){
    if (monsterList[i].DEF >= ATK) {needATK = true; return false;}
    Monster mon = monsterList[i].clone();
    mon.HP = mon.HP - (ATK - mon.DEF);
    while (HP > 0 && mon.HP > 0) {
     HP = HP - (mon.ATK - DEF);
     mon.HP = mon.HP - (ATK - mon.DEF);
    }
    if ( HP <= 0) {
     return false;
    }
   }
  }
  return true;
 }
 
 // let the character fight with the monster and decrease HP
 public void fight(Monster mon){
  try{
   int monHP = mon.HP;
   monHP = mon.HP - (ATK - mon.DEF);
   while (HP > 0 && monHP > 0) {
    HP = HP - (mon.ATK - DEF);
    monHP = monHP - (ATK - mon.DEF);
   }
   if (HP <= 0)
    throw new Exception();
  }
  catch(Exception e){
   System.out.println("lose");
  }
 }
 
 public String randomItemType() {
  String item;
  if ((key+randomCount)%3 == 0) item = "I01";
  else item = "I00";
  randomCount++;
  if (needATK) {needATK = false; item = "I00";}
  return item;
 }
 
 public static String[][] readMap(String fileName){
   String[][] map = new String[11][11];
   try{
     BufferedReader in = new BufferedReader(new FileReader(fileName));
     String str;
     int i = 0;
     
     while ((str = in.readLine()) != null){
       for (int j = 0;j<44;j+=4){
         map[i][(int)j/4] = str.substring(j, j+4);
       }
       i++;
     }
   }
   catch (IOException e) {
     System.out.println("sb");
   }
   return map;
 }
 
 public void readConfig(String fileName) {
  try {
    BufferedReader in = new BufferedReader(new FileReader(fileName));
    String str;
    str = in.readLine();
    for (int i = 0; i < str.length(); i++){
     int subkey = str.charAt(i);
     key += (int)subkey;
    }
    str = in.readLine();
    level = Integer.parseInt(str);
    
    in.close();
    } catch (IOException e) {
    System.out.println("ErrorReadConfig");
  }
 }
 
 public static void main(String[] args) throws InterruptedException {
  // TODO Auto-generated method stub
  
  int key = 0;
  MapItemGenerator config = new MapItemGenerator(0);
  config.readConfig("config.txt");
  int totalLevel = config.level;
  key = (int) config.key;
  
  
  int HP = 100;
  int ATK = 10;
  int DEF = 10;
  
  for (int i = 1; i < totalLevel + 1; i++){
   String fileName;
   if (i < 10) fileName = ".\\map\\Map_0" + i + ".txt";
   else fileName = ".\\map\\Map_" + i + ".txt";
   String[][] map = MapItemGenerator.readMap(fileName);
   MapItemGenerator generator = new MapItemGenerator(key);
   map = generator.ItemGenerator(map, HP, ATK, DEF);
   HP = generator.HP;
   ATK = generator.ATK;
   DEF = generator.DEF;
   
   
   // write into txt file
   try {
     String l = String.valueOf(i);
     if (l.length() == 1)
       l="0"+l;
         File file = new File(".\\map\\Map_"+l+".txt");
         if (!file.exists()) 
           file.createNewFile();
         FileWriter fileWriter = new FileWriter(file);
         fileWriter.write("");
         fileWriter.flush();
         fileWriter.close();
       
         FileWriter fw = new FileWriter(file);
         for (int j = 0; j < 11; j++){
           fw.write(map[0][j]);
         }
         for (int j = 1; j < 11; j++){
           fw.write("\r\n");
           for (int k = 0; k < 11; k++){
             fw.write(map[j][k]);
           }
           
         }
         fw.close();
         
       } catch (IOException e) {
           e.printStackTrace();
       }
  }
  
 }

}
