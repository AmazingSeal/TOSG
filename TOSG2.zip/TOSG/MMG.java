import java.io.BufferedWriter;
import java.io.FileWriter;


public class MMG extends MapGeneratorAndMonsterGenerator{
 
 public static void main(String[] args){
  String c = "config.txt";
  readConfig(c);
  //
  int MaxLevel = getMaxLevel(c);
  int intSeed = GetSeed(c);
  
  
  for(int i = 1; i <= MaxLevel; i++){
   String[][] x = createMap(intSeed, i);
   x = GenerateMonster(x, i);
   String l = Integer.toString(i);
   if (l.length() == 1)
     l = "0"+l;
   String mapName = "map\\Map_" + l + ".txt";
   
   try{
    BufferedWriter bw = new BufferedWriter(new FileWriter(mapName));
    
    for(int j = 0; j < 11; j++){
     for(int k = 0; k < 11; k++){
      if(k <= 9){
       bw.write(x[j][k]);
       bw.flush();
      }
      else if(k == 10){
       bw.write(x[j][k]);
       bw.newLine();
       bw.flush();
      }
      else if(j == 10 && k == 10){
       bw.write(x[j][k]);
       bw.flush();
       bw.close();
      }
      
     }
    }
    
   }
   catch(Exception e){
    System.out.println("sb");
   }
   
  }
  
 }
 

}
