import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Font;
import javax.swing.JLabel;
import java.io.BufferedReader;
import java.awt.event.KeyAdapter;  
import java.awt.event.KeyEvent;  
import java.awt.event.KeyListener;

import java.io.*;


public class Game{
  
  private char[][] map = new char[15][28];
  private String[][] gameMap = new String[11][11];
  private int level;
  private int HP;
  private int ATK;
  private int DEF;
  private int MHP;
  private int MATK;
 private int MDEF;
  private String MNAME;
  private int UHP;
  private int UATK;
  private int UDEF;
  private String UNAME;
  private int KEY;
  private int x;
  private int y;
  private int tempx;
  private int tempy;
  private int totallevel;
  
  /* read config file */
   public void readConfig(String fileName) {
    
    try {
      BufferedReader in = new BufferedReader(new FileReader(fileName));
      String str;
      str = in.readLine();
      str = in.readLine();
      totallevel = Integer.parseInt(str);

      in.close();
    } catch (IOException e) {
      System.out.println("ErrorReadConfig");
    }
    
  }
   
   /* remove temp maps and set initial value */
   public void init() {
     try{
     HP = 100;
     ATK = 10;
     DEF = 10;
     KEY = 0;
     level = 1;
     File file = new File("gamestate.txt");
      if (!file.exists()) 
        file.createNewFile();
      FileWriter fileWriter = new FileWriter(file);
      fileWriter.write("");
      fileWriter.flush();
      fileWriter.close();
      FileWriter fw = new FileWriter(file);
      fw.write(String.valueOf(level));
      fw.write("\r\n");
      fw.write(String.valueOf(HP));
      fw.write("\r\n");
      fw.write(String.valueOf(ATK));
      fw.write("\r\n");
      fw.write(String.valueOf(DEF));
      fw.write("\r\n");
      fw.write(String.valueOf(KEY));
      fw.close();
      File temp = new File("./tempmap");
      File[] tempfiles = temp.listFiles();
      if (tempfiles != null){
        for (File f: tempfiles){
          f.delete();
        }
      }
     } catch (IOException e) {
      System.out.println("ErrorInitiate");
    }

   }
  
   /* read temp maps */
  public void readTemp(String fileName) {
    
    try {
      BufferedReader in = new BufferedReader(new FileReader(fileName));
      String str;
      int i = 0;
      while ((str = in.readLine()) != null) {
        for (int j = 0;j<28;j++){
          if (str.charAt(j) == '~')
            map[i][j] = ' ';
          else
            map[i][j] = str.charAt(j);
        }
        
        i++;
      }
      in.close();
    } catch (IOException e) {
      System.out.println("ErrorReadTemp");
    }
    
  }
  
  /* read event file */
  public void readEvent(String fileName) {
    
    try {
      BufferedReader in = new BufferedReader(new FileReader("./event/"+fileName));
      String str;
      int i = 0;
      while ((str = in.readLine()) != null) {
        for (int j = 0;j<13;j++){
          if (i > 7){
            if (str.charAt(j) == '~')
              map[i][j] = ' ';
            else
              map[i][j] = str.charAt(j);
          }
        }
        
        i++;
      }
      in.close();
    } catch (IOException e) {
      System.out.println("ErrorReadEvent");
    }
    
  }
  
  /* read current level map */
  public void readGame(String fileName) {
    
    try {
      BufferedReader in;
      File file = new File("./tempmap/"+fileName);
      if (!file.exists()) {
       in = new BufferedReader(new FileReader("./map/"+fileName));
      }
      else{
        in = new BufferedReader(new FileReader("./tempmap/"+fileName));
      }
      String str;
      int i = 0;
      while ((str = in.readLine()) != null) {
        for (int j = 0;j<11;j++){
          
          gameMap[i][j] = str.substring(j*4,j*4+4);
          if (gameMap[i][j].charAt(0) == '~')
            map[2+i][j+15] = ' ';
          else
            map[2+i][j+15] = gameMap[i][j].charAt(0);
        }
        System.out.print("\n");
        
        i++;
      }
      
        
      in.close();
    } catch (IOException e) {
      System.out.println("ErrorReadGame");
    }
    
  }
  
  /* read gamestate file */
  public void readGameState(String fileName) {
    
    try {
      BufferedReader in = new BufferedReader(new FileReader(fileName));
      String str;
      str = in.readLine();
      level = Integer.parseInt(str);   
      
      str = in.readLine();
      HP = Integer.parseInt(str);
      for (int i = 0; i < str.length(); i++)
        map[2][5+i] = str.charAt(i);
      
      str = in.readLine();
      ATK = Integer.parseInt(str);
      for (int i = 0; i < str.length(); i++)
        map[3][6+i] = str.charAt(i);
      
      str = in.readLine();
      DEF = Integer.parseInt(str);
      for (int i = 0; i < str.length(); i++)
        map[4][6+i] = str.charAt(i);
      
      str = in.readLine();
      KEY = Integer.parseInt(str);
      for (int i = 0; i < str.length(); i++)
        map[7][6+i] = str.charAt(i);
      

      in.close();
      
    } catch (IOException e) {
      System.out.println("ErrorReadGameState");
    }
    
  }
  
  /* read monster file */
  public void readMonster(String fileName) {
    
    try {
      BufferedReader in = new BufferedReader(new FileReader("./monster/"+fileName));
      String str;      
      
      str = in.readLine();
      MHP = Integer.parseInt(str);
      
      str = in.readLine();
      MATK = Integer.parseInt(str);
      
      str = in.readLine();
      MDEF = Integer.parseInt(str);
      
      str = in.readLine();
      MNAME = str;
      

      in.close();
      
    } catch (IOException e) {
      System.out.println("ErrorReadMonster");
    }
    
  }
  
  /* read item file */
  public void readUnit(String fileName) {
    
    try {
      BufferedReader in = new BufferedReader(new FileReader("./unit/"+fileName));
      String str;      
      
      str = in.readLine();
      UHP = Integer.parseInt(str);
      
      str = in.readLine();
      UATK = Integer.parseInt(str);
      
      str = in.readLine();
      System.out.println(str);
      UDEF = Integer.parseInt(str);
      
      str = in.readLine();
      UNAME = str;
      

      in.close();
      
    } catch (IOException e) {
      System.out.println("ErrorReadItem");
    }
    
  }
  
  /* save current level */
  public void savelevel(){
    
    try {
      String l = String.valueOf(level);
      if (l.length()==1)
        l = "0"+l;
      File file = new File("./tempmap/Map_"+l+".txt");
      if (!file.exists()) 
        file.createNewFile();
      FileWriter fileWriter = new FileWriter(file);
      fileWriter.write("");
      fileWriter.flush();
      fileWriter.close();
    
      FileWriter fw = new FileWriter(file);
      for (int j = 0; j < 11; j++){

        fw.write(gameMap[0][j]);
      }
      for (int i = 1; i < 11; i++){
        fw.write("\r\n");

        for (int j = 0; j < 11; j++){
          fw.write(gameMap[i][j]);

        }
        
      }
      fw.close();
      
    } catch (IOException e) {
        e.printStackTrace();
    }

    
  }
  
  /* convert map to html */
  public String getMap(){
    StringBuilder tempStr = new StringBuilder();
    tempStr.append("<html><body>");
    for (int i = 0; i<15; i++){
      for (int j = 0; j< 28; j++){
        if (map[i][j] == ' ')
          tempStr.append("&nbsp;");
        else
          tempStr.append(map[i][j]);
      }
      tempStr.append("<br>");
    }
    tempStr.append("</body></html>");
    return tempStr.toString();
  }
  
  /* get location of character */
  public void getC(){
    for (int i = 0; i<11;i++){
      for (int j = 0; j<11;j++){
        if (map[i+2][j+15] == 'C'){
          x = i;
          y = j;
        }
      }
    }
  }
  
  /* updata map after preformaning action */
  public void renew(int addx, int addy){
    getC();
    int event = 0;
    tempx = x + addx;
    tempy = y + addy;
    if (tempx < 0 || tempy < 0 || tempx >=11 || tempy >= 11){
      event = 0;
    }
    else if (map[2+tempx][15+tempy] == ' '){
     event = 1; 
    }
    else if (map[2+tempx][15+tempy] == 'W'){
      event = 0;
    }
    else if (map[2+tempx][15+tempy] == 'D'){
      event = 2;
    }
    else if (map[2+tempx][15+tempy] == 'K'){
      event = 3;
    }
    else if (map[2+tempx][15+tempy] == 'M'){
      event = 4;
    }
    else if (map[2+tempx][15+tempy] == 'S'){
      event = 5;
    }
    else if (map[2+tempx][15+tempy] == 'I' || map[2+tempx][15+tempy] == 'P'){
      event = 6;
    }
    
    act(event);
    
  }
  
  /* performing action */
  public void act(int event){
    switch (event){
      case 0:
        readEvent("wall.txt");
        break;
      case 1:
        map[x+2][y+15] = ' ';
        map[tempx+2][tempy+15] = 'C';
        gameMap[x][y] = "~000";
        gameMap[tempx][tempy] = "C000";
        x = tempx;
        y = tempy;
        readEvent("empty.txt");

        break;
      case 2:
        if (KEY >= 1){
        KEY--;
        for (int i = 0; i<7;i++){
          String str = String.valueOf(KEY);
          if (i<str.length())
            map[7][i+6] = str.charAt(i);
          else
            map[7][i+6] = ' ';
        }
        map[x+2][y+15] = ' ';
        map[tempx+2][tempy+15] = 'C';
        gameMap[x][y] = "~000";
        gameMap[tempx][tempy] = "C000";
        x = tempx;
        y = tempy;
        readEvent("opendoor.txt");
      }
        else 
          readEvent("closedoor.txt");

        break;
      case 3:
        KEY++;
        for (int i = 0; i<7;i++){
          String str = String.valueOf(KEY);
          if (i<str.length())
            map[7][i+6] = str.charAt(i);
          else
            map[7][i+6] = ' ';
        }
        map[x+2][y+15] = ' ';
        map[tempx+2][tempy+15] = 'C';
        gameMap[x][y] = "~000";
        gameMap[tempx][tempy] = "C000";
        x = tempx;
        y = tempy;
        readEvent("getkey.txt");

        break;
      case 4:
        readMonster(gameMap[tempx][tempy]+".txt");
        if (Beat()){
          map[x+2][y+15] = ' ';
          map[tempx+2][tempy+15] = 'C';
          gameMap[x][y] = "~000";
          gameMap[tempx][tempy] = "C000";
          x = tempx;
          y = tempy;
          readEvent("beat.txt");
          for (int i = 0; i<11;i++){
            
            if (i<MNAME.length())
              map[11][i+2] = MNAME.charAt(i);
            else
              map[11][i+2] = ' ';
          }
          map[11][MNAME.length()+2] = '.';
          
        }
        else
          readEvent("fail.txt");

        break;
      case 5:
        savelevel();
        if (level == 1 && gameMap[tempx][tempy].charAt(3) == '0'){
          readEvent("birth.txt");
        }else {
        if (gameMap[tempx][tempy].charAt(3) == '0')
          level--;
        else
          level++;
        String l = String.valueOf(level);
        if (l.length()==1)
          l = "0"+l;
        readGame("Map_"+l+".txt");
        
        readEvent("empty.txt");
        }
        break;
      
    case 6:
      readUnit(gameMap[tempx][tempy]+".txt");
      map[x+2][y+15] = ' ';
          map[tempx+2][tempy+15] = 'C';
          gameMap[x][y] = "~000";
          gameMap[tempx][tempy] = "C000";
          x = tempx;
          y = tempy;
          readEvent("beat.txt");
          HP += UHP;
          ATK += UATK;
          DEF += UDEF;
          
          for (int i = 0; i < 7; i++)
            map[2][5+i] = ' ';
          String SHP = String.valueOf(HP);
          for (int i = 0; i < SHP.length(); i++)
            map[2][5+i] = SHP.charAt(i);
          
          for (int i = 0; i < 7; i++)
            map[3][6+i] = ' ';
          String SATK = String.valueOf(ATK);
          for (int i = 0; i < SATK.length(); i++)
            map[3][6+i] = SATK.charAt(i);
          
          for (int i = 0; i < 7; i++)
            map[4][6+i] = ' ';
          String SDEF = String.valueOf(DEF);
          for (int i = 0; i < SDEF.length(); i++)
            map[4][6+i] = SDEF.charAt(i);
          
          readEvent("item.txt");
          for (int i = 0; i<11;i++){
            
            if (i<UNAME.length())
              map[11][i+2] = UNAME.charAt(i);
            else
              map[11][i+2] = ' ';
          }
          map[11][UNAME.length()+2] = '.';
          break;
    }
    } 
  
  /* test the result of battle */
  public boolean Beat(){
   int ea = ATK-MDEF;
   int ed = MATK-DEF;
   if (ea <= 0)
     ea = 1;
   if (ed <= 0)
     ed = 1;
   if (HP/ed >= MHP/ea){
     HP = HP - ed *((int)Math.ceil((double)MHP/ea) - 1);
     for (int i = 0; i < 7; i++)
        map[2][5+i] = ' ';
     String SHP = String.valueOf(HP);
     for (int i = 0; i < SHP.length(); i++)
        map[2][5+i] = SHP.charAt(i);
     return true;
   }
   else
     return false;
  }
  
  /* save the game */
 public void save(){
   savelevel();
   for (int i = 1; i<= totallevel;i++){
     
     
     try {
       File file =new File(".\\tempmal\\tempmap_"+level+".txt");
       File ofile = new File(".\\map\\map_"+level+".txt");
       if (file.exists()){
         FileWriter fileWriter =new FileWriter(ofile);
         fileWriter.write("");
         fileWriter.flush();
         fileWriter.close();
         
         FileWriter fw = new FileWriter(ofile);
         BufferedReader in = new BufferedReader(new FileReader(file));
         String str;

         str = in.readLine();
         
         while (str!= null) {
           fw.write("\r\n");
           fw.write(str);
           str = in.readLine();
         }
         in.close();
         fw.close();
       }
       File gamefile = new File("gamestate.txt");
       FileWriter fw = new FileWriter(gamefile);
       fw.write(String.valueOf(level));
       fw.write("\r\n");
       fw.write(String.valueOf(HP));
       fw.write("\r\n");
       fw.write(String.valueOf(ATK));
       fw.write("\r\n");
       fw.write(String.valueOf(DEF));
       fw.write("\r\n");
       fw.write(String.valueOf(KEY));
       fw.close();
       
       
       
     } catch (IOException e) {
       e.printStackTrace();
     }
     
     
     
     }
   readEvent("save.txt");
 }
 
 /* load the latest saved game */
 public void load(){
   readTemp("tempMap.txt"); 
   readGameState("gamestate.txt");
   String s = String.valueOf(level);
    if (s.length()==1)
      s = "0"+s;
   readGame("Map_"+s+".txt");
   readEvent("load.txt");
 }
  
  public static void main(String[] args){
    Game game = new Game();
    game.readTemp("tempMap.txt"); 
    game.init();
    game.readGameState("gamestate.txt");
    String s = String.valueOf(game.level);
    if (s.length()==1)
      s = "0"+s;
    game.readGame("Map_"+s+".txt");
    game.readConfig("config.txt");
        
    JFrame frame = new JFrame("Tower of the Sorcerer");
   JPanel p = new JPanel();
    JLabel panel = new JLabel(game.getMap());
    frame.addKeyListener(new KeyListener(){
      public void keyPressed(KeyEvent e){
        int x = 0;
        int y = 0;
        JLabel newpanel;
        JPanel newp;
        switch(e.getKeyCode())
        {
          case KeyEvent.VK_UP:
          case KeyEvent.VK_W:
            x=-1;
            y=0;
            game.renew(x,y);
            frame.getContentPane().removeAll();
            newpanel = new JLabel(game.getMap());
            newp = new JPanel();
            frame.setFocusable(true);
            newpanel.setFont(new Font("Courier New",Font.PLAIN, 23));
            newp.add(newpanel);
            frame.add(newp);
            frame.validate();
            frame.repaint();
            break;
          case KeyEvent.VK_DOWN:
          case KeyEvent.VK_S:
            x=1;
            y=0;
            game.renew(x,y);
            frame.getContentPane().removeAll();
            newpanel = new JLabel(game.getMap());
            newp = new JPanel();
            frame.setFocusable(true);
            newpanel.setFont(new Font("Courier New",Font.PLAIN, 23));
            newp.add(newpanel);
            frame.add(newp);
            frame.validate();
            frame.repaint();
            break;
          case KeyEvent.VK_LEFT:
          case KeyEvent.VK_A:
            x=0;
            y=-1;
            game.renew(x,y);
            frame.getContentPane().removeAll();
            newpanel = new JLabel(game.getMap());
            newp = new JPanel();
            frame.setFocusable(true);
            newpanel.setFont(new Font("Courier New",Font.PLAIN, 23));
            newp.add(newpanel);
            frame.add(newp);
            frame.validate();
            frame.repaint();
            break;
          case KeyEvent.VK_RIGHT:
          case KeyEvent.VK_D:
            x=0;
            y=1;
            game.renew(x,y);
            frame.getContentPane().removeAll();
            newpanel = new JLabel(game.getMap());
            newp = new JPanel();
            frame.setFocusable(true);
            newpanel.setFont(new Font("Courier New",Font.PLAIN, 23));
            newp.add(newpanel);
            frame.add(newp);
            frame.validate();
            frame.repaint();
            break;
          case KeyEvent.VK_I:
            game.load();
            frame.getContentPane().removeAll();
            newpanel = new JLabel(game.getMap());
            newp = new JPanel();
            frame.setFocusable(true);
            newpanel.setFont(new Font("Courier New",Font.PLAIN, 23));
            newp.add(newpanel);
            frame.add(newp);
            frame.validate();
            frame.repaint();
            break;      
          case KeyEvent.VK_O:
            game.save();
            frame.getContentPane().removeAll();
            newpanel = new JLabel(game.getMap());
            newp = new JPanel();
            frame.setFocusable(true);
            newpanel.setFont(new Font("Courier New",Font.PLAIN, 23));
            newp.add(newpanel);
            frame.add(newp);
            frame.validate();
            frame.repaint();
            break; 
        }
        
      }
      
      @Override
      public void keyTyped(KeyEvent e) {
      }
      @Override
      public void keyReleased(KeyEvent e) {
      }
    });
   frame.setFocusable(true);
    panel.setFont(new Font("Courier New",Font.PLAIN, 23));
    p.add(panel);
    frame.add(p);
    frame.pack();
    frame.setVisible(true);
    
  }
}

class MyKeyMonitor extends KeyAdapter {
    public void keyPressed(KeyEvent e) {
      int keyCode = e.getKeyCode();
      
      if(keyCode == KeyEvent.VK_UP) {
        System.out.println("up");
        
      }
      
      if(keyCode == KeyEvent.VK_DOWN) {
        System.out.println("down");
        
      }
      
      if(keyCode == KeyEvent.VK_LEFT) {
        System.out.println("left");
        
      }
      
      if(keyCode == KeyEvent.VK_RIGHT) {
        System.out.println("right");
        
      }
      
    }
    
  }